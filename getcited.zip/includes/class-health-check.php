<?php
/**
 * Health checks for GetCited
 *
 * @package GetCited
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Health Check class
 */
class GetCited_Health_Check {

    /**
     * Single instance
     */
    private static $instance = null;

    /**
     * Transient name for cached status
     */
    const TRANSIENT_NAME = 'getcited_health_status';

    /**
     * Get instance
     */
    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Transient for tracking async check in progress
     */
    const ASYNC_LOCK_TRANSIENT = 'getcited_health_async_lock';

    /**
     * Stale threshold in seconds (30 minutes)
     */
    const STALE_THRESHOLD = 1800;

    /**
     * Constructor
     */
    private function __construct() {
        // AJAX handler for manual health check
        add_action( 'wp_ajax_getcited_health_check', array( $this, 'ajax_run_checks' ) );

        // Async health check handler
        add_action( 'getcited_async_health_check', array( $this, 'perform_async_check' ) );
    }

    /**
     * Invalidate the health check cache
     *
     * Called by other classes when they make changes that affect health status.
     */
    public function invalidate_cache() {
        delete_transient( self::TRANSIENT_NAME );
    }

    /**
     * Run all health checks
     */
    public function run_checks() {
        $status = array(
            'llms_txt' => $this->check_llms_txt(),
            'robots_txt' => $this->check_robots_txt(),
            'schema' => $this->check_schema(),
            'rewrite_rules' => $this->check_rewrite_rules(),
            'crawler_list' => $this->check_crawler_list(),
            'caching_plugins' => $this->check_caching_plugins(),
            'security_plugins' => $this->check_security_plugins(),
            'environment' => $this->check_environment(),
            'redirection' => $this->check_redirection_plugin(),
            'jetpack' => $this->check_jetpack_plugin(),
            'last_checked' => current_time( 'c' ),
        );

        // Calculate overall status
        $status['overall'] = $this->calculate_overall( $status );

        // Cache result
        set_transient( self::TRANSIENT_NAME, $status, HOUR_IN_SECONDS );

        // Fire hook
        do_action( 'getcited_health_check_complete', $status );

        return $status;
    }

    /**
     * Get cached status or run checks
     *
     * Returns cached status immediately for fast dashboard loads.
     * Schedules background refresh if data is stale.
     *
     * @param bool $force_sync Force synchronous check (bypass async).
     * @return array Health status data.
     */
    public function get_status( $force_sync = false ) {
        $status = get_transient( self::TRANSIENT_NAME );

        // No cached data - must run synchronously
        if ( $status === false ) {
            return $this->run_checks();
        }

        // Force sync requested
        if ( $force_sync ) {
            return $this->run_checks();
        }

        // Check if data is stale and schedule background refresh
        if ( $this->is_stale( $status ) ) {
            $this->schedule_async_check();
        }

        return $status;
    }

    /**
     * Check if cached status is stale
     *
     * @param array $status Cached status data.
     * @return bool True if stale.
     */
    private function is_stale( $status ) {
        if ( empty( $status['last_checked'] ) ) {
            return true;
        }

        $last_checked = strtotime( $status['last_checked'] );
        $now = current_time( 'timestamp' );

        return ( $now - $last_checked ) > self::STALE_THRESHOLD;
    }

    /**
     * Schedule async health check if not already scheduled
     */
    private function schedule_async_check() {
        // Prevent duplicate scheduling
        if ( get_transient( self::ASYNC_LOCK_TRANSIENT ) ) {
            return;
        }

        // Set lock to prevent duplicate checks
        set_transient( self::ASYNC_LOCK_TRANSIENT, 1, 5 * MINUTE_IN_SECONDS );

        // Schedule for immediate execution
        if ( ! wp_next_scheduled( 'getcited_async_health_check' ) ) {
            wp_schedule_single_event( time(), 'getcited_async_health_check' );
        }
    }

    /**
     * Perform async health check (called by cron)
     */
    public function perform_async_check() {
        // Clear lock
        delete_transient( self::ASYNC_LOCK_TRANSIENT );

        // Run the actual checks
        $this->run_checks();
    }

    /**
     * Force refresh status
     */
    public function refresh() {
        delete_transient( self::TRANSIENT_NAME );
        return $this->run_checks();
    }

    /**
     * AJAX handler for health check
     *
     * Supports modes:
     * - 'refresh' (default): Force synchronous refresh
     * - 'poll': Return cached data with freshness indicator (for polling after async refresh)
     */
    public function ajax_run_checks() {
        check_ajax_referer( 'getcited_admin', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Permission denied' );
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above
        $mode = isset( $_POST['mode'] ) ? sanitize_text_field( wp_unslash( $_POST['mode'] ) ) : 'refresh';

        if ( 'poll' === $mode ) {
            // Poll mode: return cached data with async status
            $status = get_transient( self::TRANSIENT_NAME );
            $is_refreshing = (bool) get_transient( self::ASYNC_LOCK_TRANSIENT );

            wp_send_json_success( array(
                'status'        => $status ? $status : null,
                'is_refreshing' => $is_refreshing,
                'is_stale'      => $status ? $this->is_stale( $status ) : true,
            ) );
        }

        // Default: force synchronous refresh
        $status = $this->refresh();
        wp_send_json_success( $status );
    }

    /**
     * Check llms.txt accessibility
     */
    private function check_llms_txt() {
        $settings = GetCited_Settings::instance();
        $detector = GetCited_Conflict_Detector::instance();
        $llms     = GetCited_Llms_Txt::instance();
        $summary  = $detector->get_llms_txt_summary();

        if ( ! $settings->get( 'llms_txt_enabled' ) ) {
            return array(
                'status' => 'disabled',
                'message' => __( 'AI Visibility Data is disabled', 'getcited' ),
                'action_type' => 'settings_link',
                'action_url' => admin_url( 'admin.php?page=getcited-llms-txt' ),
                'action_label' => __( 'Enable AI Visibility Data', 'getcited' ),
            );
        }

        // Check for physical file conflicts (dynamic serving is primary since v1.9.9.18)
        if ( $summary['physical_file_exists'] ) {
            $file_path = ABSPATH . 'llms.txt';

            // Use WP_Filesystem for consistent file operations
            global $wp_filesystem;
            if ( ! function_exists( 'WP_Filesystem' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            WP_Filesystem();

            $content = $wp_filesystem->get_contents( $file_path );

            // Check if it's our legacy file (from pre-v1.9.9.18)
            if ( $content && strpos( $content, '# Generated by GetCited' ) !== false ) {
                // Our legacy physical file - delete it and proceed to standard check.
                // Physical files from older versions should be cleaned up.
                $llms->delete_physical_file();
                // Fall through to standard fetch check below.
            } else {
                // Not our file - show conflict with disable instructions
                $seo_conflict = $llms->check_seo_plugin_conflict();
                $source_name  = $seo_conflict ? $seo_conflict['name'] : __( 'Another source', 'getcited' );
                $instructions = $seo_conflict ? $seo_conflict['instructions'] : __( 'Check your SEO plugin settings and disable its llms.txt feature.', 'getcited' );

                return array(
                    'status' => 'warning',
                    'message' => sprintf(
                        /* translators: %s: source name */
                        __( '%s is overriding GetCited', 'getcited' ),
                        $source_name
                    ),
                    'details' => $instructions,
                    'action_type' => 'resolve_conflict',
                    'url' => home_url( '/llms.txt' ),
                );
            }
        }

        // Standard fetch check
        $url = home_url( '/llms.txt' );

        $response = wp_remote_get( $url, array( 'timeout' => 5 ) );

        if ( is_wp_error( $response ) ) {
            return array(
                'status' => 'error',
                'message' => __( 'Could not fetch llms.txt', 'getcited' ),
                'details' => $response->get_error_message(),
                'url' => $url,
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code === 404 ) {
            return array(
                'status' => 'error',
                'message' => __( 'llms.txt returns 404 Not Found', 'getcited' ),
                'details' => __( 'The rewrite rules may need flushing. Go to Settings → Permalinks and click Save Changes.', 'getcited' ),
                'action_type' => 'permalinks_link',
                'action_url' => admin_url( 'options-permalink.php' ),
                'action_label' => __( 'Go to Permalinks', 'getcited' ),
                'url' => $url,
            );
        }

        if ( $code !== 200 ) {
            return array(
                'status' => 'error',
                /* translators: %d: HTTP response code */
                'message' => sprintf( __( 'llms.txt returned HTTP %d', 'getcited' ), $code ),
                'url' => $url,
            );
        }

        // Check for our marker
        if ( strpos( $body, '# Generated by GetCited' ) === false ) {
            $source = $this->identify_llms_txt_source( $body );

            return array(
                'status' => 'warning',
                'message' => __( 'llms.txt served by another source', 'getcited' ),
                'details' => $source
                    ? sprintf(
                        /* translators: %s: name of conflicting source */
                        __( '%s appears to be serving llms.txt. Disable their llms.txt feature or use theirs instead.', 'getcited' ),
                        $source
                    )
                    : __( 'The llms.txt file is accessible but not generated by GetCited. Another plugin or a physical file may be serving it.', 'getcited' ),
                'url' => $url,
                'content_preview' => substr( $body, 0, 500 ),
            );
        }

        return array(
            'status' => 'ok',
            'message' => __( 'llms.txt is accessible and working', 'getcited' ),
            'url' => $url,
        );
    }

    /**
     * Try to identify the source of llms.txt content
     *
     * @param string $content The llms.txt content
     * @return string|false Source name or false if unknown
     */
    private function identify_llms_txt_source( $content ) {
        // Check for known signatures
        $signatures = array(
            'Yoast SEO' => array( 'yoast', 'Yoast' ),
            'Rank Math' => array( 'rank-math', 'Rank Math', 'rankmath' ),
            'All in One SEO' => array( 'aioseo', 'All in One SEO', 'AIOSEO' ),
            'SEOPress' => array( 'seopress', 'SEOPress' ),
            'JERL' => array( 'jerl', 'JERL' ),
            'LLMs.txt Plugin' => array( 'llms-txt', 'LLMs.txt' ),
            'WP LLMs' => array( 'wp-llms', 'WP LLMs' ),
        );

        foreach ( $signatures as $name => $keywords ) {
            foreach ( $keywords as $keyword ) {
                if ( stripos( $content, $keyword ) !== false ) {
                    return $name;
                }
            }
        }

        // Check if it looks like a manual/physical file
        if ( strpos( $content, '# Generated' ) === false ) {
            return __( 'Physical file or unknown source', 'getcited' );
        }

        return false;
    }

    /**
     * Check robots.txt for our rules
     */
    private function check_robots_txt() {
        $robots = GetCited_Robots::instance();
        $detector = GetCited_Conflict_Detector::instance();
        $summary = $detector->get_robots_txt_summary();

        // Check if site discourages search engines
        $is_public = get_option( 'blog_public' );
        if ( ! $is_public ) {
            return array(
                'status' => 'error',
                'message' => __( 'Search engine visibility is disabled in WordPress settings', 'getcited' ),
                'details' => __( 'Uncheck "Discourage search engines" in Settings → Reading to allow AI crawlers.', 'getcited' ),
                'action_type' => 'settings_link',
                'action_url' => admin_url( 'options-reading.php' ),
                'action_label' => __( 'Go to Reading Settings', 'getcited' ),
            );
        }

        // Check for physical robots.txt file
        if ( $summary['physical_file_exists'] ) {
            $rules_exist = $robots->rules_exist_in_physical_file();

            // Rules already present
            if ( $rules_exist ) {
                $result = array(
                    'status' => 'ok',
                    'message' => __( 'GetCited rules present in robots.txt', 'getcited' ),
                );

                // Note if SEO plugin editor is available
                if ( $summary['seo_plugin_with_editor'] ) {
                    $result['details'] = sprintf(
                        /* translators: %s: SEO plugin name */
                        __( 'Physical file managed alongside %s. Edit via GetCited Crawlers page or the SEO plugin editor.', 'getcited' ),
                        $summary['seo_plugin_with_editor']['name']
                    );
                }

                return $result;
            }

            // Physical file exists, rules not present
            $result = array(
                'status' => 'warning',
                'message' => __( 'Physical robots.txt exists — GetCited rules not added yet', 'getcited' ),
                'rules' => $robots->generate_rules(),
                'can_write' => $summary['physical_file_writable'],
            );

            // Build details message
            if ( $summary['seo_plugin_with_editor'] ) {
                $result['details'] = sprintf(
                    /* translators: %s: SEO plugin name */
                    __( 'A robots.txt file exists, likely managed by %s. You can add GetCited rules automatically, or add them through your SEO plugin editor.', 'getcited' ),
                    $summary['seo_plugin_with_editor']['name']
                );
                $result['seo_plugin'] = $summary['seo_plugin_with_editor'];
            } elseif ( ! empty( $summary['hooks_detected'] ) ) {
                // Other plugins detected but no known editor
                $plugin_names = array();
                foreach ( $summary['hooks_detected'] as $hook ) {
                    if ( $hook['plugin_info'] ) {
                        $plugin_names[] = $hook['plugin_info']['name'];
                    } elseif ( $hook['plugin'] ) {
                        $plugin_names[] = ucfirst( $hook['plugin'] );
                    }
                }
                $plugin_names = array_unique( $plugin_names );

                if ( ! empty( $plugin_names ) ) {
                    $result['details'] = sprintf(
                        /* translators: %s: comma-separated list of plugin names */
                        __( 'A robots.txt file exists. Detected plugins that may modify it: %s. You can add GetCited rules automatically.', 'getcited' ),
                        implode( ', ', $plugin_names )
                    );
                    $result['detected_plugins'] = $plugin_names;
                } else {
                    $result['details'] = __( 'A physical robots.txt file exists in your site root. GetCited can add its rules automatically.', 'getcited' );
                }
            } else {
                $result['details'] = __( 'A physical robots.txt file exists in your site root. GetCited can add its rules automatically.', 'getcited' );
            }

            // Set action type based on write capability
            if ( $summary['physical_file_writable'] ) {
                $result['action_type'] = 'auto_add';
                $result['action_label'] = __( 'Add Rules to robots.txt', 'getcited' );
            } else {
                $result['action_type'] = 'copy_rules';
                $result['details'] .= ' ' . __( 'Automatic addition is not available due to file permissions.', 'getcited' );
            }

            return $result;
        }

        // No physical file - using WordPress filter
        // Fetch and check robots.txt content
        $url = home_url( '/robots.txt' );

        $response = wp_remote_get( $url, array( 'timeout' => 5 ) );

        if ( is_wp_error( $response ) ) {
            return array(
                'status' => 'error',
                'message' => __( 'Could not fetch robots.txt', 'getcited' ),
                'details' => $response->get_error_message(),
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            return array(
                'status' => 'error',
                /* translators: %d: HTTP response code */
                'message' => sprintf( __( 'robots.txt returned HTTP %d', 'getcited' ), $code ),
                'details' => __( 'The robots.txt file could not be loaded. Check your server configuration.', 'getcited' ),
            );
        }

        // Check for our marker
        if ( strpos( $body, '# === GetCited AI Crawler Rules ===' ) === false ) {
            // Check if other hooks might be interfering
            if ( ! empty( $summary['potential_conflicts'] ) ) {
                $conflict_names = array_map( function ( $c ) {
                    return $c['plugin'];
                }, $summary['potential_conflicts'] );

                return array(
                    'status' => 'warning',
                    'message' => __( 'GetCited rules may be overwritten', 'getcited' ),
                    'details' => sprintf(
                        /* translators: %s: comma-separated list of plugin names */
                        __( 'The following plugins run after GetCited and may be removing or overwriting the rules: %s. Try adjusting plugin load order or contact support.', 'getcited' ),
                        implode( ', ', $conflict_names )
                    ),
                    'hooks_info' => $summary['hooks_detected'],
                );
            }

            return array(
                'status' => 'warning',
                'message' => __( 'GetCited rules not found in robots.txt', 'getcited' ),
                'details' => __( 'The rules should be added automatically. Try deactivating and reactivating GetCited, or flush your permalinks by visiting Settings → Permalinks and clicking Save.', 'getcited' ),
                'action_type' => 'permalinks_link',
                'action_url' => admin_url( 'options-permalink.php' ),
                'action_label' => __( 'Go to Permalinks', 'getcited' ),
                'rules' => $robots->generate_rules(),
            );
        }

        // All good - rules present
        $result = array(
            'status' => 'ok',
            'message' => __( 'robots.txt includes GetCited rules', 'getcited' ),
        );

        // Note other hooks if present
        if ( ! empty( $summary['hooks_detected'] ) ) {
            $plugin_names = array();
            foreach ( $summary['hooks_detected'] as $hook ) {
                if ( $hook['plugin_info'] ) {
                    $plugin_names[] = $hook['plugin_info']['name'];
                }
            }
            $plugin_names = array_unique( $plugin_names );

            if ( ! empty( $plugin_names ) ) {
                $result['details'] = sprintf(
                    /* translators: %s: comma-separated list of plugin names */
                    __( 'Also detected: %s. All plugins are cooperating correctly.', 'getcited' ),
                    implode( ', ', $plugin_names )
                );
            }
        }

        return $result;
    }

    /**
     * Check schema output
     */
    private function check_schema() {
        $settings = GetCited_Settings::instance();
        $detector = GetCited_Schema_Detector::instance();

        // Check for conflicts using schema detector.
        $detection = $detector->get_detection_status();
        $conflicts = $detection['plugins'] ?? array();

        // If schema is disabled in settings, check if SEO plugin handles it.
        if ( ! $settings->get( 'schema_enabled' ) ) {
            // If SEO plugin is handling schema, show OK status (v1.5.4).
            if ( ! empty( $conflicts ) ) {
                $names = array_map( function( $p ) { return $p['name']; }, $conflicts );
                return array(
                    'status' => 'ok',
                    'message' => sprintf(
                        /* translators: %s: comma-separated list of detected schema plugin names */
                        __( 'Schema handled by %s', 'getcited' ),
                        implode( ', ', $names )
                    ),
                    'conflicts' => $conflicts,
                );
            }
            return array(
                'status' => 'disabled',
                'message' => __( 'Schema output is disabled', 'getcited' ),
            );
        }

        if ( ! empty( $conflicts ) ) {
            $names = array_map( function( $p ) { return $p['name']; }, $conflicts );

            // Check if user force-enabled schema.
            if ( $settings->get( 'schema_force_enabled' ) ) {
                return array(
                    'status' => 'warning',
                    'message' => sprintf(
                        /* translators: %s: comma-separated list of detected schema plugin names */
                        __( 'Schema force-enabled despite %s detected. May cause duplicates.', 'getcited' ),
                        implode( ', ', $names )
                    ),
                    'conflicts' => $conflicts,
                );
            }

            return array(
                'status' => 'ok',
                'message' => sprintf(
                    /* translators: %s: comma-separated list of detected schema plugin names */
                    __( 'Schema auto-disabled — %s is handling schema.', 'getcited' ),
                    implode( ', ', $names )
                ),
                'conflicts' => $conflicts,
            );
        }

        // Check for JSON-LD detected on homepage.
        if ( ! empty( $detection['json_ld_found'] ) && ! $settings->get( 'schema_force_enabled' ) ) {
            return array(
                'status' => 'ok',
                'message' => __( 'Schema auto-disabled — existing JSON-LD detected on homepage.', 'getcited' ),
            );
        }

        $schema_types = $settings->get( 'schema_types' );
        $enabled = array_filter( $schema_types );

        if ( empty( $enabled ) ) {
            return array(
                'status' => 'warning',
                'message' => __( 'Schema is enabled but no schema types are selected', 'getcited' ),
            );
        }

        return array(
            'status' => 'ok',
            'message' => sprintf(
                /* translators: %s: comma-separated list of enabled schema types */
                __( 'Schema enabled for: %s', 'getcited' ),
                implode( ', ', array_keys( $enabled ) )
            ),
        );
    }

    /**
     * Check rewrite rules are flushed
     */
    private function check_rewrite_rules() {
        global $wp_rewrite;

        $rules = $wp_rewrite->wp_rewrite_rules();

        if ( ! isset( $rules['^llms\.txt$'] ) ) {
            return array(
                'status' => 'warning',
                'message' => __( 'Rewrite rules may need flushing. Visit Settings > Permalinks to refresh.', 'getcited' ),
            );
        }

        return array(
            'status' => 'ok',
            'message' => __( 'Rewrite rules are properly configured', 'getcited' ),
        );
    }

    /**
     * Check crawler list freshness
     */
    private function check_crawler_list() {
        $crawler_list = GetCited_Crawler_List::instance();

        $is_remote = $crawler_list->is_remote_cached();
        $version = $crawler_list->get_version();
        $updated = $crawler_list->get_last_updated();

        // If using bundled list, show OK status (bundled list is valid and usable)
        if ( ! $is_remote ) {
            return array(
                'status' => 'ok',
                'message' => sprintf(
                    /* translators: %s: version number */
                    __( 'Using bundled crawler list v%s', 'getcited' ),
                    $version
                ),
                'version' => $version,
                'updated' => $updated,
                'details' => __( 'Remote sync will be attempted automatically. The bundled list is fully functional.', 'getcited' ),
            );
        }

        return array(
            'status' => 'ok',
            'message' => sprintf(
                /* translators: %1$s: version number, %2$s: last updated date */
                __( 'Crawler list v%1$s (updated %2$s)', 'getcited' ),
                $version,
                $updated
            ),
            'version' => $version,
            'updated' => $updated,
        );
    }

    /**
     * Check for caching plugins and provide guidance
     */
    private function check_caching_plugins() {
        $detected = array();

        // WP Super Cache
        if ( defined( 'WPCACHEHOME' ) || is_plugin_active( 'wp-super-cache/wp-cache.php' ) ) {
            $detected[] = array(
                'name' => 'WP Super Cache',
                'slug' => 'wp-super-cache',
                'docs' => 'https://developer.wordpress.org/plugins/wp-super-cache/',
            );
        }

        // W3 Total Cache
        if ( defined( 'W3TC' ) || is_plugin_active( 'w3-total-cache/w3-total-cache.php' ) ) {
            $detected[] = array(
                'name' => 'W3 Total Cache',
                'slug' => 'w3-total-cache',
                'docs' => 'https://www.boldgrid.com/w3-total-cache/',
            );
        }

        // WP Rocket
        if ( defined( 'WP_ROCKET_VERSION' ) || is_plugin_active( 'wp-rocket/wp-rocket.php' ) ) {
            $detected[] = array(
                'name' => 'WP Rocket',
                'slug' => 'wp-rocket',
                'docs' => 'https://docs.wp-rocket.me/',
            );
        }

        // LiteSpeed Cache
        if ( defined( 'LSCWP_V' ) || is_plugin_active( 'litespeed-cache/litespeed-cache.php' ) ) {
            $detected[] = array(
                'name' => 'LiteSpeed Cache',
                'slug' => 'litespeed-cache',
                'docs' => 'https://docs.litespeedtech.com/lscache/lscwp/',
            );
        }

        // SG Optimizer (SiteGround)
        if ( defined( 'SG_CACHEPRESS_VERSION' ) || is_plugin_active( 'sg-cachepress/sg-cachepress.php' ) ) {
            $detected[] = array(
                'name' => 'SG Optimizer',
                'slug' => 'sg-optimizer',
                'docs' => 'https://www.siteground.com/kb/sg-optimizer/',
            );
        }

        // WP Fastest Cache
        if ( defined( 'WPFC_WP_PLUGIN_DIR' ) || is_plugin_active( 'wp-fastest-cache/wpFastestCache.php' ) ) {
            $detected[] = array(
                'name' => 'WP Fastest Cache',
                'slug' => 'wp-fastest-cache',
                'docs' => 'https://www.wpfastestcache.com/',
            );
        }

        // Autoptimize
        if ( defined( 'AUTOPTIMIZE_PLUGIN_VERSION' ) || is_plugin_active( 'autoptimize/autoptimize.php' ) ) {
            $detected[] = array(
                'name' => 'Autoptimize',
                'slug' => 'autoptimize',
                'docs' => 'https://developer.wordpress.org/plugins/autoptimize/',
            );
        }

        // Breeze (Cloudways)
        if ( defined( 'BREEZE_VERSION' ) || is_plugin_active( 'breeze/breeze.php' ) ) {
            $detected[] = array(
                'name' => 'Breeze',
                'slug' => 'breeze',
                'docs' => 'https://developer.wordpress.org/plugins/breeze/',
            );
        }

        if ( empty( $detected ) ) {
            return array(
                'status' => 'ok',
                'message' => __( 'No caching plugins detected', 'getcited' ),
            );
        }

        $names = array_column( $detected, 'name' );

        return array(
            'status' => 'info',
            'message' => sprintf(
                /* translators: %s: comma-separated list of caching plugin names */
                __( 'Caching plugin detected: %s', 'getcited' ),
                implode( ', ', $names )
            ),
            'details' => __( 'If llms.txt is not updating after changes, exclude /llms.txt from page caching in your cache plugin settings. GetCited already sets appropriate Cache-Control headers.', 'getcited' ),
            'plugins' => $detected,
        );
    }

    /**
     * Check for security plugins and provide guidance
     */
    private function check_security_plugins() {
        $detected = array();

        // Wordfence
        if ( defined( 'WORDFENCE_VERSION' ) || is_plugin_active( 'wordfence/wordfence.php' ) ) {
            $detected[] = array(
                'name' => 'Wordfence',
                'slug' => 'wordfence',
                'docs' => 'https://www.wordfence.com/help/',
                'whitelist_setting' => 'Rate Limiting → Whitelist',
            );
        }

        // Sucuri
        if ( defined( 'SUCURISCAN_VERSION' ) || is_plugin_active( 'sucuri-scanner/sucuri.php' ) ) {
            $detected[] = array(
                'name' => 'Sucuri',
                'slug' => 'sucuri',
                'docs' => 'https://docs.sucuri.net/',
                'whitelist_setting' => 'Firewall → Whitelist',
            );
        }

        // iThemes Security / Solid Security
        if ( defined( 'ITSEC_Core' ) || is_plugin_active( 'better-wp-security/better-wp-security.php' ) || is_plugin_active( 'ithemes-security-pro/ithemes-security-pro.php' ) ) {
            $detected[] = array(
                'name' => 'Solid Security (iThemes)',
                'slug' => 'solid-security',
                'docs' => 'https://developer.wordpress.org/plugins/better-wp-security/',
                'whitelist_setting' => 'Security → Lockouts → Whitelist',
            );
        }

        // All In One WP Security
        if ( defined( 'AIO_WP_SECURITY_VERSION' ) || is_plugin_active( 'all-in-one-wp-security-and-firewall/wp-security.php' ) ) {
            $detected[] = array(
                'name' => 'All In One WP Security',
                'slug' => 'aio-wp-security',
                'docs' => 'https://developer.wordpress.org/plugins/all-in-one-wp-security-and-firewall/',
                'whitelist_setting' => 'WP Security → Brute Force → Bot Prevention',
            );
        }

        // Shield Security
        if ( defined( 'ICWP_DS' ) || is_plugin_active( 'wp-simple-firewall/icwp-wpsf.php' ) ) {
            $detected[] = array(
                'name' => 'Shield Security',
                'slug' => 'shield-security',
                'docs' => 'https://getshieldsecurity.com/documentation/',
                'whitelist_setting' => 'Configuration → Traffic → Whitelist',
            );
        }

        // NinjaFirewall
        if ( defined( 'NFW_ENGINE_VERSION' ) || is_plugin_active( 'ninjafirewall/ninjafirewall.php' ) ) {
            $detected[] = array(
                'name' => 'NinjaFirewall',
                'slug' => 'ninjafirewall',
                'docs' => 'https://nintechnet.com/ninjafirewall/wp-edition/',
                'whitelist_setting' => 'NinjaFirewall → Access Control',
            );
        }

        if ( empty( $detected ) ) {
            return array(
                'status' => 'ok',
                'message' => __( 'No security plugins detected', 'getcited' ),
            );
        }

        $names = array_column( $detected, 'name' );

        // Common AI crawler user-agents
        $ai_crawlers = array(
            'Googlebot', 'Bingbot', 'GPTBot', 'ChatGPT-User', 'Claude-Web',
            'anthropic-ai', 'Perplexity', 'CCBot', 'YouBot', 'cohere-ai',
        );

        return array(
            'status' => 'info',
            'message' => sprintf(
                /* translators: %s: comma-separated list of security plugin names */
                __( 'Security plugin detected: %s', 'getcited' ),
                implode( ', ', $names )
            ),
            'details' => __( 'If AI crawlers are blocked, consider whitelisting their user-agents in your security plugin. Common AI crawlers include: GPTBot, ChatGPT-User, Claude-Web, anthropic-ai, Perplexity.', 'getcited' ),
            'plugins' => $detected,
            'ai_crawlers' => $ai_crawlers,
        );
    }

    /**
     * Check environment (staging/development detection)
     */
    private function check_environment() {
        $env_type = $this->detect_environment_type();
        $is_staging = $this->is_staging_environment();

        if ( $is_staging ) {
            return array(
                'status' => 'info',
                'message' => sprintf(
                    /* translators: %s: environment type */
                    __( 'Staging/development environment detected: %s', 'getcited' ),
                    $env_type
                ),
                'details' => __( 'Some features like external llms.txt verification may be skipped on staging environments. Request logging can also be disabled for development.', 'getcited' ),
                'environment_type' => $env_type,
                'is_staging' => true,
            );
        }

        return array(
            'status' => 'ok',
            'message' => __( 'Production environment', 'getcited' ),
            'environment_type' => $env_type,
            'is_staging' => false,
        );
    }

    /**
     * Check if hostname matches staging/development patterns
     *
     * Uses precise regex matching to avoid false positives like:
     * - "developer.example.com" matching ".dev."
     * - "contest-site.com" matching "test-"
     *
     * @param string $host The hostname to check.
     * @return bool True if matches a staging pattern.
     */
    private function matches_staging_hostname( $host ) {
        if ( empty( $host ) ) {
            return false;
        }

        $host = strtolower( $host );

        // Remove port if present.
        $host = preg_replace( '/:\d+$/', '', $host );

        // Exact matches for localhost/loopback.
        if ( in_array( $host, array( 'localhost', '127.0.0.1' ), true ) ) {
            return true;
        }

        // TLD-based patterns (must end with these).
        $tld_patterns = array( '.local', '.test', '.localhost' );
        foreach ( $tld_patterns as $tld ) {
            if ( substr( $host, -strlen( $tld ) ) === $tld ) {
                return true;
            }
        }

        // Subdomain patterns (must have dots on both sides).
        $subdomain_patterns = array( '.staging.', '.dev.', '.test.', '.local.' );
        foreach ( $subdomain_patterns as $pattern ) {
            if ( strpos( $host, $pattern ) !== false ) {
                return true;
            }
        }

        // Prefix patterns (must be at the start of hostname).
        $prefix_patterns = array( 'staging-', 'dev-', 'test-', 'staging.', 'dev.', 'local.' );
        foreach ( $prefix_patterns as $prefix ) {
            if ( strpos( $host, $prefix ) === 0 ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Detect environment type
     *
     * @return string Environment identifier
     */
    private function detect_environment_type() {
        // WordPress 5.5+ environment type
        if ( function_exists( 'wp_get_environment_type' ) ) {
            $env = wp_get_environment_type();
            if ( in_array( $env, array( 'local', 'development', 'staging' ), true ) ) {
                return $env;
            }
        }

        // Check common staging URL patterns
        $host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';

        if ( $this->matches_staging_hostname( $host ) ) {
            return 'staging (URL pattern)';
        }

        // Check debug constants combination
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
            return 'development (debug enabled)';
        }

        return 'production';
    }

    /**
     * Check if current environment is staging/development
     *
     * @return bool True if staging/development environment
     */
    public function is_staging_environment() {
        // WordPress 5.5+ environment type
        if ( function_exists( 'wp_get_environment_type' ) ) {
            $env = wp_get_environment_type();
            if ( in_array( $env, array( 'local', 'development', 'staging' ), true ) ) {
                return true;
            }
        }

        // Check URL patterns
        $host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';

        return $this->matches_staging_hostname( $host );
    }

    /**
     * Check for Redirection plugin and conflicting rules
     */
    private function check_redirection_plugin() {
        // Check if Redirection plugin is active
        if ( ! is_plugin_active( 'redirection/redirection.php' ) ) {
            return array(
                'status' => 'ok',
                'message' => __( 'Redirection plugin not detected', 'getcited' ),
            );
        }

        // Plugin is active - check for conflicting rules
        global $wpdb;

        // Redirection stores rules in wp_redirection_items table
        $redirection_table = esc_sql( $wpdb->prefix . 'redirection_items' );

        // Check if table exists
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking external plugin table
        $table_exists = $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s',
                DB_NAME,
                $redirection_table
            )
        );

        if ( ! $table_exists ) {
            return array(
                'status' => 'info',
                'message' => __( 'Redirection plugin detected', 'getcited' ),
                'details' => __( 'Ensure no redirect rules exist for /llms.txt to avoid breaking AI crawler access.', 'getcited' ),
                'plugin' => array(
                    'name' => 'Redirection',
                    'slug' => 'redirection',
                    'docs' => 'https://redirection.me/support/',
                ),
            );
        }

        // Check for rules matching llms.txt (enabled rules only, status=enabled)
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Checking external plugin table for conflicts
        $conflicting_rules = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, url, action_data, action_type FROM `{$redirection_table}` WHERE status = 'enabled' AND (url LIKE %s OR url LIKE %s OR url = %s)", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name from $wpdb->prefix is safe
                '%llms.txt%',
                '%llms%txt%',
                '/llms.txt'
            )
        );

        if ( ! empty( $conflicting_rules ) ) {
            return array(
                'status' => 'warning',
                'message' => __( 'Redirection rule may affect llms.txt', 'getcited' ),
                'details' => sprintf(
                    /* translators: %d: number of conflicting rules */
                    __( 'Found %d redirect rule(s) that may affect /llms.txt. This could prevent AI crawlers from accessing your llms.txt file. Review your Redirection settings.', 'getcited' ),
                    count( $conflicting_rules )
                ),
                'plugin' => array(
                    'name' => 'Redirection',
                    'slug' => 'redirection',
                    'docs' => 'https://redirection.me/support/',
                ),
                'conflicting_rules' => array_map( function( $rule ) {
                    return array(
                        'id' => $rule->id,
                        'url' => $rule->url,
                        'target' => $rule->action_data,
                    );
                }, $conflicting_rules ),
                'action_type' => 'settings_link',
                'action_url' => admin_url( 'tools.php?page=redirection.php' ),
                'action_label' => __( 'Review Redirection Rules', 'getcited' ),
            );
        }

        return array(
            'status' => 'ok',
            'message' => __( 'Redirection plugin detected, no llms.txt conflicts', 'getcited' ),
            'plugin' => array(
                'name' => 'Redirection',
                'slug' => 'redirection',
                'docs' => 'https://redirection.me/support/',
            ),
        );
    }

    /**
     * Check for Jetpack plugin and potential conflicts
     */
    private function check_jetpack_plugin() {
        // Check if Jetpack is active
        if ( ! defined( 'JETPACK__VERSION' ) && ! is_plugin_active( 'jetpack/jetpack.php' ) ) {
            return array(
                'status' => 'ok',
                'message' => __( 'Jetpack not detected', 'getcited' ),
            );
        }

        $concerns = array();
        $modules_active = array();

        // Check for active modules that might conflict
        if ( class_exists( 'Jetpack' ) && method_exists( 'Jetpack', 'is_module_active' ) ) {
            // SEO Tools module (paid feature, but check anyway)
            if ( Jetpack::is_module_active( 'seo-tools' ) ) {
                $modules_active[] = 'SEO Tools';
                $concerns[] = __( 'SEO Tools module is active - may add schema markup', 'getcited' );
            }

            // Sitemaps module
            if ( Jetpack::is_module_active( 'sitemaps' ) ) {
                $modules_active[] = 'Sitemaps';
                // Sitemaps don't conflict directly, just informational
            }

            // Photon CDN
            if ( Jetpack::is_module_active( 'photon' ) ) {
                $modules_active[] = 'Photon CDN';
                // CDN doesn't affect llms.txt, just informational
            }

            // Search module
            if ( Jetpack::is_module_active( 'search' ) ) {
                $modules_active[] = 'Search';
            }
        }

        // Build response based on what we found
        if ( ! empty( $concerns ) ) {
            return array(
                'status' => 'info',
                'message' => __( 'Jetpack detected with active modules', 'getcited' ),
                'details' => implode( '. ', $concerns ) . '. ' . __( 'GetCited schema detection should handle this automatically, but monitor for duplicate schema if issues arise.', 'getcited' ),
                'plugin' => array(
                    'name' => 'Jetpack',
                    'slug' => 'jetpack',
                    'docs' => 'https://jetpack.com/support/',
                ),
                'modules_active' => $modules_active,
            );
        }

        if ( ! empty( $modules_active ) ) {
            return array(
                'status' => 'ok',
                'message' => sprintf(
                    /* translators: %s: comma-separated list of active Jetpack modules */
                    __( 'Jetpack detected (%s)', 'getcited' ),
                    implode( ', ', $modules_active )
                ),
                'plugin' => array(
                    'name' => 'Jetpack',
                    'slug' => 'jetpack',
                    'docs' => 'https://jetpack.com/support/',
                ),
                'modules_active' => $modules_active,
            );
        }

        return array(
            'status' => 'ok',
            'message' => __( 'Jetpack detected', 'getcited' ),
            'plugin' => array(
                'name' => 'Jetpack',
                'slug' => 'jetpack',
                'docs' => 'https://jetpack.com/support/',
            ),
        );
    }

    /**
     * Calculate overall status
     */
    private function calculate_overall( $status ) {
        $checks = array( 'llms_txt', 'robots_txt', 'schema', 'rewrite_rules', 'crawler_list', 'caching_plugins', 'security_plugins', 'environment', 'redirection', 'jetpack' );
        
        $has_error = false;
        $has_warning = false;

        foreach ( $checks as $check ) {
            if ( isset( $status[ $check ]['status'] ) ) {
                if ( $status[ $check ]['status'] === 'error' ) {
                    $has_error = true;
                } elseif ( $status[ $check ]['status'] === 'warning' ) {
                    $has_warning = true;
                }
            }
        }

        if ( $has_error ) {
            return 'error';
        }

        if ( $has_warning ) {
            return 'warning';
        }

        return 'ok';
    }

    /**
     * Get status label
     */
    public function get_status_label( $status ) {
        $labels = array(
            'ok' => __( 'Healthy', 'getcited' ),
            'warning' => __( 'Needs Attention', 'getcited' ),
            'error' => __( 'Error', 'getcited' ),
            'disabled' => __( 'Disabled', 'getcited' ),
        );

        return $labels[ $status ] ?? $status;
    }

    /**
     * Get status color class
     */
    public function get_status_class( $status ) {
        $classes = array(
            'ok' => 'getcited-status-ok',
            'warning' => 'getcited-status-warning',
            'error' => 'getcited-status-error',
            'disabled' => 'getcited-status-disabled',
        );

        return $classes[ $status ] ?? '';
    }

    /**
     * Verify llms.txt is actually accessible via HTTP
     *
     * Makes a real HTTP request to verify the endpoint works from the outside world.
     *
     * @return array {
     *     'accessible'    => bool,
     *     'status_code'   => int,
     *     'has_marker'    => bool,      // Contains "Generated by GetCited"
     *     'response_time' => float,     // milliseconds
     *     'error'         => string|null,
     *     'suggestion'    => string|null
     * }
     */
    public function verify_llms_txt_accessible() {
        $url = home_url( '/llms.txt' );

        $start = microtime( true );
        $response = wp_remote_get( $url, array(
            'timeout'   => 5,
            'sslverify' => false,  // Self-request, skip SSL verification issues
            'headers'   => array(
                'Cache-Control' => 'no-cache',  // Try to bypass caching layers
            ),
            'user-agent' => 'GetCited-HealthCheck/' . GETCITED_VERSION,
        ) );
        $elapsed = ( microtime( true ) - $start ) * 1000;

        // Check for WP error
        if ( is_wp_error( $response ) ) {
            return array(
                'accessible'    => false,
                'status_code'   => 0,
                'has_marker'    => false,
                'response_time' => $elapsed,
                'error'         => $response->get_error_message(),
                'suggestion'    => $this->get_accessibility_suggestion( 'wp_error' ),
            );
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = wp_remote_retrieve_body( $response );
        $has_marker  = strpos( $body, '# Generated by GetCited' ) !== false;

        // Success case
        if ( $status_code === 200 && $has_marker ) {
            return array(
                'accessible'    => true,
                'status_code'   => 200,
                'has_marker'    => true,
                'response_time' => $elapsed,
                'error'         => null,
                'suggestion'    => null,
            );
        }

        // Diagnose the issue
        if ( $status_code === 404 ) {
            return array(
                'accessible'    => false,
                'status_code'   => 404,
                'has_marker'    => false,
                'response_time' => $elapsed,
                'error'         => __( 'llms.txt returned 404 Not Found', 'getcited' ),
                'suggestion'    => $this->get_accessibility_suggestion( '404' ),
            );
        }

        if ( $status_code === 200 && ! $has_marker ) {
            return array(
                'accessible'    => false,
                'status_code'   => 200,
                'has_marker'    => false,
                'response_time' => $elapsed,
                'error'         => __( 'llms.txt exists but not generated by GetCited', 'getcited' ),
                'suggestion'    => $this->get_accessibility_suggestion( 'foreign_file' ),
            );
        }

        return array(
            'accessible'    => false,
            'status_code'   => $status_code,
            'has_marker'    => false,
            'response_time' => $elapsed,
            /* translators: %d: HTTP status code */
            'error'         => sprintf( __( 'Unexpected status code: %d', 'getcited' ), $status_code ),
            'suggestion'    => $this->get_accessibility_suggestion( 'unknown' ),
        );
    }

    /**
     * Verify llms.txt with fallback URL check
     *
     * If the primary /llms.txt URL fails, checks if the fallback /?llms-txt=1 works.
     *
     * @return array {
     *     'primary'        => array,   // Result from verify_llms_txt_accessible()
     *     'fallback'       => array|null,
     *     'recommendation' => string,  // 'working', 'use_fallback', 'write_physical', 'manual_upload'
     *     'message'        => string|null
     * }
     */
    public function verify_llms_txt_with_fallback() {
        // Try primary URL first
        $primary = $this->verify_llms_txt_accessible();

        if ( $primary['accessible'] ) {
            return array(
                'primary'        => $primary,
                'fallback'       => null,
                'recommendation' => 'working',
                'message'        => null,
            );
        }

        // Primary failed - try fallback URL
        $fallback = $this->verify_fallback_url();

        if ( $fallback['accessible'] ) {
            return array(
                'primary'        => $primary,
                'fallback'       => $fallback,
                'recommendation' => 'write_physical',
                'message'        => __( 'The clean /llms.txt URL is not working, but WordPress can serve the content. Your hosting may not route .txt files through WordPress. Writing a physical file should fix this.', 'getcited' ),
            );
        }

        return array(
            'primary'        => $primary,
            'fallback'       => $fallback,
            'recommendation' => 'manual_upload',
            'message'        => __( 'Neither URL is working. You may need to manually upload the llms.txt file via SFTP.', 'getcited' ),
        );
    }

    /**
     * Verify the fallback URL (?llms-txt=1)
     *
     * @return array Same structure as verify_llms_txt_accessible()
     */
    private function verify_fallback_url() {
        $url = home_url( '/?llms-txt=1' );

        $start = microtime( true );
        $response = wp_remote_get( $url, array(
            'timeout'   => 5,
            'sslverify' => false,
            'headers'   => array(
                'Cache-Control' => 'no-cache',
            ),
            'user-agent' => 'GetCited-HealthCheck/' . GETCITED_VERSION,
        ) );
        $elapsed = ( microtime( true ) - $start ) * 1000;

        if ( is_wp_error( $response ) ) {
            return array(
                'accessible'    => false,
                'status_code'   => 0,
                'has_marker'    => false,
                'response_time' => $elapsed,
                'error'         => $response->get_error_message(),
                'suggestion'    => null,
            );
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = wp_remote_retrieve_body( $response );
        $has_marker  = strpos( $body, '# Generated by GetCited' ) !== false;

        return array(
            'accessible'    => ( $status_code === 200 && $has_marker ),
            'status_code'   => $status_code,
            'has_marker'    => $has_marker,
            'response_time' => $elapsed,
            'error'         => null,
            'suggestion'    => null,
        );
    }

    /**
     * Get actionable suggestion based on error type
     *
     * @param string $error_type The type of error encountered.
     * @return string Suggestion message.
     */
    private function get_accessibility_suggestion( $error_type ) {
        $suggestions = array(
            '404'          => __( 'Your hosting may not route .txt files through WordPress. Try: 1) Flush permalinks (Settings → Permalinks → Save), 2) If that fails, use the "Write Physical File" option, 3) If still failing, manually upload llms.txt via SFTP.', 'getcited' ),

            'foreign_file' => __( 'A llms.txt file exists but was not created by GetCited. You can either delete it and let GetCited manage it, or switch to "Use existing file" mode in settings.', 'getcited' ),

            'wp_error'     => __( 'Could not connect to your site. This might be a temporary issue, a firewall blocking loopback requests, or a server configuration problem. Try again in a few minutes.', 'getcited' ),

            'unknown'      => __( 'An unexpected error occurred. Check your server error logs for more details.', 'getcited' ),
        );

        return $suggestions[ $error_type ] ?? $suggestions['unknown'];
    }

    /**
     * Detect hosting environment for specific guidance
     *
     * @return string Hosting environment identifier.
     */
    public function detect_hosting_environment() {
        // WordPress.com
        if ( defined( 'WPCOMSH_VERSION' ) || defined( 'IS_ATOMIC' ) ) {
            return 'wordpress.com';
        }

        // Pantheon
        if ( defined( 'PANTHEON_ENVIRONMENT' ) ) {
            return 'pantheon';
        }

        // WP Engine
        if ( defined( 'WPE_APIKEY' ) ) {
            return 'wpengine';
        }

        // WordPress VIP
        if ( defined( 'WPCOM_IS_VIP_ENV' ) ) {
            return 'wordpress-vip';
        }

        // Flywheel
        if ( defined( 'FLYWHEEL_CONFIG_DIR' ) ) {
            return 'flywheel';
        }

        // Kinsta
        if ( defined( 'KINSTA_CACHE_ZONE' ) ) {
            return 'kinsta';
        }

        return 'standard';
    }

    /**
     * Get host-specific guidance for llms.txt issues
     *
     * @param string $host The hosting environment identifier.
     * @return array|null Guidance array or null if no specific guidance.
     */
    public function get_host_specific_guidance( $host ) {
        $guidance = array(
            'wordpress.com' => array(
                'title'    => __( 'WordPress.com Detected', 'getcited' ),
                'message'  => __( 'WordPress.com may not route .txt files through WordPress. If the automatic fix doesn\'t work, download your llms.txt file and upload it via SFTP.', 'getcited' ),
                'docs_url' => 'https://wordpress.com/support/add-llms-txt-to-your-site/',
            ),
            'pantheon'      => array(
                'title'    => __( 'Pantheon Detected', 'getcited' ),
                'message'  => __( 'Pantheon has a read-only filesystem in production. You\'ll need to commit llms.txt to your repository or use the Dev/Test environment to write the file.', 'getcited' ),
                'docs_url' => 'https://docs.pantheon.io/',
            ),
            'wordpress-vip' => array(
                'title'    => __( 'WordPress VIP Detected', 'getcited' ),
                'message'  => __( 'WordPress VIP has strict file restrictions. You\'ll need to commit llms.txt to your repository.', 'getcited' ),
                'docs_url' => 'https://docs.wpvip.com/',
            ),
        );

        return $guidance[ $host ] ?? null;
    }
}
